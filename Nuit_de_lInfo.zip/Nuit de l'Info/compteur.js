var compteur = 0;
var dechet; // temps qui passe -> doit devenir nb dechet par seconde
var nbArbre = 1;

/* function incrementer() {
	compteur++;
	document.getElementById("cpt").innerHTML = compteur;
	changeAiguille();
	if (nbArbre != 11){
		ajoutArbre();
		nbArbre++;
	} 
}

function cpt() {
	document.getElementById("cpt").innerHTML = "Test";
}

function init() {
	dechet = setInterval("incrementer()", 1000);
}

function changeAiguille(){
	if (compteur >= 5)
		document.getElementById("thumb").src="img/thumbdown.png";
}

function ajoutArbre() {
	var img = document.createElement('img');
	var parent = document.getElementById('compteur-arbre');
	img.setAttribute('src', 'img/arbre.png');
	parent.appendChild(img);
} */

var heure = 0;
var carbonSite = 2.6; // à mettre à jour en fonction du site

function changerHeure(){
	document.getElementById("heure_var").innerHTML = Math.round(carbonSite*100/19)/100*60;
}

function init() {
	//dechet = setInterval("changerHeure()", 1000);
	changerHeure();
}

function move_aiguille() {
	x += 0.5
	aiguille_deg = attendu*180/10 - (1/x)*180/10
	document.getElementById("aiguille").style.transform = 'rotate('+aiguille_deg+'deg)'
}

function getCo2(site) {
	var data = {
		url: "https://google.com"
	};

	var json = JSON.stringify(data);

	var xhr = new XMLHttpRequest();
	xhr.open("POST", "https://digitalbeacon.co/create");
	xhr.setRequestHeader("Content-Type", "application/json");
	xhr.send(json);
	xhr.onreadystatechange = function() { 
		if (xhr.readyState == 4){
  			if (xhr.status == 200){
				var json_data = xhr.responseText;
				console.log(json_data) 
			}
		}
	}
}